@echo off
cd /d "%~dp0"
where uvicorn >nul 2>nul
if %errorlevel% equ 0 (
    start "" uvicorn main:app --host 127.0.0.1 --port 8000
) else (
    start "" python -m uvicorn main:app --host 127.0.0.1 --port 8000
)
timeout /t 2 /nobreak >nul
start "" "http://localhost:8000"
